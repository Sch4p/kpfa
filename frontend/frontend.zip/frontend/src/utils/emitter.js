// src/utils/emitter.js
import mitt from "mitt";

export const emitter = mitt();
