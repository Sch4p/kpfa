<template>
  <div class="container py-5">
    <h2>Your Orders</h2>
    <p>Orders list will appear here soon.</p>
  </div>
</template>

<script>
export default {
    /* eslint-disable vue/multi-word-component-names */
  name: "Orders",
};
</script>
