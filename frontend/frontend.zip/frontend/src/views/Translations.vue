
Yoruba	Iye or Opó	Iye is general; Opó can imply count or amount
Hausa	Yawan	Refers to amount or number
Igbo	Ọnụ ọgụgụ	Literally means "number" or "count"
Twi (Akan)	Dodow	Refers to quantity or number
Ga	Kɛjiɛ	Used to express amount or volume
Arabic	الكمية (al-kammiyya)


French	Avis	Pas encore d'avis
Yoruba	Àtúnwò	Ko si àtúnwò kankan sibẹ
Hausa	Bita	Babu bita tukuna
Igbo	Nyocha	Enweghị nyocha ugbu a
Twi (Akan)	Nsɛnkɔm	Nsɛnkɔm biara nni hɔ
Ga	Nɔtsui	Nɔtsui kɛ nɔ baa
Arabic	المراجعات




Phrase	French	Yoruba	Hausa	Igbo	Twi	Ga	Arabic
Search by player name	Rechercher par nom du joueur	Wa nipasẹ orukọ ẹrọ orin	Nema ta sunan ɗan wasa	Chọọ aha onye egwuregwu	Hwe din agorɔni	Hwe agboŋŋmli lɛ	البحث حسب اسم اللاعب
Position	Poste	Ipo	Matsayi	Ọnọdụ	Ɔdan	Gbɛjɛ	المركز
Country	Pays	Orilẹ̀-èdè	Ƙasa	Ụlọ̀ọrụ̀ mba	Ɔman	Gbɛmlɛ	الدولة
Load More	Charger plus	Gbe diẹ sii	Ɗora ƙari	Bugharịkwu ọzọ	Tɔ so bio	Hɔɔ kɛ nyɛ	تحميل المزيد